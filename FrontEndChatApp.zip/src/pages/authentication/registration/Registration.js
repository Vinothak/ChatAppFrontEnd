import React, { Component } from 'react';
import { Alert, Form, Button } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';
import { DebounceInput } from 'react-debounce-input';

import ChatHttpServer from '../../../utils/ChatHttpServer';
import './Registration.css';

class Registration extends Component {

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      usernameAvailable: true,
      dummyusername:"",
      dummypassword:""
    };
  }

  handleRegistration = async (event) => {
    event.preventDefault();
    this.props.loadingState(true);
   
    try {
      const response = await ChatHttpServer.register(this.state);
      this.props.loadingState(false);

      if (response.error) {
        alert('Unable to register, try after some time.')
      } else if(response.message=='Username is unavailable.'){

        alert('Username is taken already');
        this.setState({
          username:null
        })
      }
        else{
        ChatHttpServer.setLS('userid', response.userId);
       
        this.setState({
          dummyusername:"",
          dummypassword:""
        },()=> alert('you are registered'))
      }
    } catch (error) {
      this.props.loadingState(false);
      alert('Unable to register, try after some time.')
    }
  }

  handleUsername = async (event)  => {
    this.setState({
      username: event.target.value,
      dummyusername:event.target.value
   });
  }

  handleInputChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
      dummypassword:event.target.value
    });
  }

  render() {
    return (
      <Form className="auth-form">
        <Form.Group controlId="formUsername">
          <DebounceInput
            className="form-control"
            placeholder = "Enter username"
            minLength={2}
            value={this.state.dummyusername}
            debounceTimeout={300}
            onChange={this.handleUsername} />
          <Alert className={{
            'username-availability-warning' : true,
            'visibility-hidden': this.state.usernameAvailable
          }}  variant="danger">
            <strong>{this.state.username}</strong> is already taken, try another username.
          </Alert>
        </Form.Group>

        <Form.Group controlId="formPassword">
          <Form.Control 
            type = "password"
            name = "password"
            placeholder = "Password"
            value={this.state.dummypassword}
            onChange = {
              this.handleInputChange
            }
          />
        </Form.Group>
        <Button variant="primary" type="submit" onClick={this.handleRegistration}>
          Registration
        </Button>
      </Form>
    );
  }
}

export default withRouter(Registration)
