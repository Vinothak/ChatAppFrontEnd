import React, { Component } from 'react';

import ChatSocketServer from '../../../utils/ChatSocketServer';
import "./ChatList.css";

class ChatList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      selectedUserId: null,
      currUser:null,
      chatListUsers: []
    }
  }

  componentDidMount() {
    const userId = this.props.userId;
    this.setState({
      currUser:userId
    })

    ChatSocketServer.establishSocketConnection(this.props.userId);
    ChatSocketServer.getChatList(userId);
    ChatSocketServer.eventEmitter.on('chat-list-response', this.createChatListUsers);
  }

  componentWillUnmount() {
    ChatSocketServer.eventEmitter.removeListener('chat-list-response', 
    this.createChatListUsers);
  }

  createChatListUsers = (chatListResponse) => {    
    if (!chatListResponse.error) {
      let chatListUsers = this.state.chatListUsers;
      console.log('chat list users create response',chatListResponse);
      console.log('chat list state already there',this.state.chatListUsers)
      console.log('current user is',this.props.userId);
      let currUser=this.state.currUser;
      if (chatListResponse.singleUser) {
        console.log('comes inside here');
        console.log(chatListResponse.chatList.length);
        if (chatListResponse.chatList.length > 0) {
       
          chatListUsers = chatListResponse.chatList.filter((obj)=> {
           return obj._id !== this.state.currUser
          });
        }
      } else if (chatListResponse.userDisconnected) {
           var newChatList=this.state.chatListUsers.map(user=>{
            return (user._id===chatListResponse.userid)?user.online='N':user
          })

        }
   else{
        /* Updating entire chat list if user logs in. */
        
        chatListUsers = chatListResponse.chatList.filter((obj)=> {
          return obj._id !== currUser
         });
      }
      console.log('before set state value is',chatListUsers);
      this.setState({
        chatListUsers: chatListUsers
      },console.log('updates state is',this.state.chatListUsers));
    } else {
      console.log(chatListResponse);
      alert(`Unable to load Chat list, Redirecting to Login.`);
    }
    this.setState({
      loading: false
    });
  }
 
  selectedUser = (user) => {
    console.log(user);
    this.setState({
      selectedUserId: user._id
    });
    this.props.updateSelectedUser(user)
  }

  render() {
    return (
      <>
        <ul className={`user-list ${this.state.chatListUsers.length === 0 ? 'visibility-hidden' : ''}`} >
          {
            this.state.chatListUsers.map( (user, index) => 
              <li 
                key={index} 
                className={this.state.selectedUserId === user.id ? 'active' : ''}
                onClick={() => this.selectedUser(user)}
              >
                {user.name}
                <span className={user.online === 'Y' ? 'online' : 'offline'}></span>
              </li>
            )
          }
        </ul>
        <div className={`alert 
          ${this.state.loading ? 'alert-info' : ''} 
          ${this.state.chatListUsers.length > 0 ? 'visibility-hidden' : ''}`
        }>
          { this.state.loading|| this.state.chatListUsers.length.length === 0 ? 'Loading your chat list.' : 'No User Available to chat.'}
        </div>
      </>
    );
  }
}

export default ChatList;
